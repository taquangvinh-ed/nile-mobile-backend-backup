package com.nilemobile.backend.config;

public class JwtContant {
    public static final String SECRET_KEY = "qazwsx135qzedcrfvtgbyhnujmik123456789";
    public static final String JWT_HEADER = "Authorization";

}
