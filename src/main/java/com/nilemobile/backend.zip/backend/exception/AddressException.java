package com.nilemobile.backend.exception;

public class AddressException extends Exception {
    public AddressException(String message) {
        super(message);
    }
}
