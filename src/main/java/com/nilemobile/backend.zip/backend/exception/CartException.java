package com.nilemobile.backend.exception;

public class CartException extends RuntimeException{
    public CartException(String s) {
        super(s);
    }
}
