package com.nilemobile.backend.exception;

public class CartItemException extends RuntimeException {
    public CartItemException(String message) {
        super(message);
    }
}
