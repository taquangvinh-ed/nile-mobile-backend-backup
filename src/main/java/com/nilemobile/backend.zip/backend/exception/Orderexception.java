package com.nilemobile.backend.exception;

public class Orderexception extends RuntimeException {
    public Orderexception(String message) {
        super(message);
    }
}
