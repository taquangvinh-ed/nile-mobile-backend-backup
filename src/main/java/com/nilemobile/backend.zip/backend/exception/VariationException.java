package com.nilemobile.backend.exception;

public class VariationException extends Exception {
    public VariationException(String message) {
        super(message);
    }
}
