package com.nilemobile.backend.model;

public enum PaymentMethod {
    VNPAY,
    CASH_ON_DELIVERY,
    BANK_CARD,
    MOMO,
    ZALOPAY
}
